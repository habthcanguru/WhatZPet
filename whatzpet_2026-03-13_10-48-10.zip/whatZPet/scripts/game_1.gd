extends Node2D

var current_minutes: int = 8 * 60
var end_minutes: int = 26 * 60
var day : int = 1

@onready var timer: Timer = $Timer
@onready var days: Label = $CanvasLayer/Control2/Days
@onready var time: Label = $CanvasLayer/Control2/Time


func _ready():
	timer.timeout.connect(_on_timer_timeout)
	timer.start()
	update_text()

func _on_timer_timeout():
	if current_minutes < end_minutes:
		current_minutes += 10
		update_text()
	else:
		current_minutes = 8 * 60
		day += 1

func update_text():
	var hours = current_minutes / 60
	var minutes = current_minutes % 60
	
	if hours >= 24:
		hours -= 24
	
	time.text = "%02d:%02d" % [hours, minutes]
	days.text = str(day)
