extends ColorRect
@onready var game_1: Node2D = $".."

var morning_color = Color(0.584, 0.539, 1.0, 0.114)     # 08:00
var evening_color = Color(1.0, 0.502, 0.2, 0.22)     # 18:00
var night_color = Color(0.051, 0.051, 0.2, 0.424)     # 22:00

func _process(delta):
	var minutes = game_1.current_minutes

	if minutes >= 480 and minutes < 960:
		var t = float(minutes - 480) / (960 - 480)
		color = morning_color.lerp(evening_color, t)

	elif minutes >= 960 and minutes < 1320:
		var t = float(minutes - 960) / (1320 - 960)
		color = evening_color.lerp(night_color, t)

	#else:
		#var t = float(minutes - 1200) / (1440 - 1260)
		#color = night_color.lerp(morning_color, t)
