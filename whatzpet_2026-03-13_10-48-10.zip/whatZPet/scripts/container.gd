extends Control

@onready var hungry: Label = $Hungry
@onready var happiness: Label = $Happiness
@onready var exhaustion: Label = $Exhaustion

@onready var pet_1: CharacterBody2D = $"../../Pet1"


#@onready var pet_1: CharacterBody2D = $"../Pet1"


func _process(_delta: float) -> void:
	hungry.text = "Hungry: " + str(pet_1.hungry)
	happiness.text = "Hapinnes: " + str(pet_1.happiness)
	exhaustion.text = "Exhaustion: " + str(pet_1.exhaustion)
