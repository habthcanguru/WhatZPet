extends CharacterBody2D

var level: int = 2
var hungry: int = 10
var exhaustion: int = 10
var happiness: int = 10

var finalPosition: Vector2
var passedTime: float = 10
var canMove: bool = true
var speed: float = 200

var animationSpeed: float = 40
var animationFrequency: float = 4
var animationStretch: float = 0.1
var playing_walk := false

@onready var animated_sprite_2d: AnimatedSprite2D = $AnimatedSprite2D
@onready var control: Control = $Control

func _ready() -> void:
	finalPosition = global_position
	if level == 2:
		animated_sprite_2d.play("EggyFacing")

func _physics_process(_delta: float) -> void:
	characterAnimation(_delta)
	
	if Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT) and canMove:
		movementDelay()
		
	if level == 2:
		_on_animated_sprite_2d_animation_finished()
	
	var distance = global_position.distance_to(finalPosition)
	
	if distance > 5 and canMove:
		var direction = global_position.direction_to(finalPosition)
		velocity = direction * speed
		
		if not playing_walk:
			animated_sprite_2d.play("EggyWalkie")
			playing_walk = true
	else:
		velocity = Vector2.ZERO
		
		if distance <= 5:
			global_position = finalPosition
			animationSpeed = 5
			
		
	move_and_slide()
	
func characterAnimation(delta: float) -> void:
	passedTime += delta * animationSpeed
	var oscillation = sin(passedTime) * animationStretch
	
	animated_sprite_2d.scale.y = 2 + oscillation
	animated_sprite_2d.scale.x = 2 - oscillation
	
func movementDelay() -> void:
	var newPosition = get_global_mouse_position()
	if newPosition.distance_to(finalPosition) > 50:
		canMove = false
		await get_tree().create_timer(0.3).timeout
		finalPosition = newPosition
		canMove = true

func _on_timer_1_timeout() -> void:
	var decreaseStatus = randi() % 3
	
	match decreaseStatus:
		0:
			hungry = max(hungry - 1, 0)
		1:
			exhaustion = max(exhaustion - 1, 0)
		2:
			happiness = max(happiness - 1, 0)
			
	if hungry == 0 or exhaustion == 0 or happiness == 0:
		#print("Um dos status chegou a 0")
		pass
		
func characterPressed(event: InputEventMouseButton) -> void:
	if event.button_index == MOUSE_BUTTON_LEFT:
		print("a")
		
func _on_animated_sprite_2d_animation_finished():
	if animated_sprite_2d.animation == "EggyWalkie":
		playing_walk = false
		if velocity == Vector2.ZERO:
			animated_sprite_2d.play("EggyFacing")
			
func _input(event):
	if event is InputEventMouseButton and event.pressed:
		if event.button_index == MOUSE_BUTTON_LEFT:
			finalPosition = get_global_mouse_position()
			
